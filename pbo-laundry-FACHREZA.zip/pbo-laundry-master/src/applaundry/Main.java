
package applaundry;

import java.util.Scanner;


public class Main {

    
   public static void main(String[] args) {
        MenuCucian m = new MenuCucian();
        m.tampilkanAllTranaski();
        m.tambahkanCucian();
    }
    
    
}
